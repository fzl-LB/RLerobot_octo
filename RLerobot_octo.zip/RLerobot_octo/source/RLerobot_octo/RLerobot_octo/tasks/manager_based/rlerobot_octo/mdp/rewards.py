# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import torch
from typing import TYPE_CHECKING

from isaaclab.assets import Articulation
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import wrap_to_pi,quat_apply


if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv

def quat_to_euler(quat: torch.Tensor):
    """Convert quaternion to euler angles (roll, pitch, yaw) in radians.
    Expects quaternion format (x, y, z, w) and shape (N, 4)
    """
    x, y, z, w = quat.unbind(dim=-1)

    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll_x = torch.atan2(t0, t1)

    t2 = +2.0 * (w * y - z * x)
    t2 = torch.clamp(t2, -1.0, 1.0)
    pitch_y = torch.asin(t2)

    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw_z = torch.atan2(t3, t4)

    return torch.stack([roll_x, pitch_y, yaw_z], dim=-1)  # (N, 3)

def quat_to_matrix(quat: torch.Tensor) -> torch.Tensor:
    # quat: (N, 4) assumed to be in (w, x, y, z) format
    w, x, y, z = quat.unbind(-1)

    # Compute terms
    B = quat.shape[0]
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    xw, yw, zw = x * w, y * w, z * w

    # Assemble rotation matrix
    rot = torch.stack([
        1 - 2*(yy + zz), 2*(xy - zw),     2*(xz + yw),
        2*(xy + zw),     1 - 2*(xx + zz), 2*(yz - xw),
        2*(xz - yw),     2*(yz + xw),     1 - 2*(xx + yy)
    ], dim=-1).reshape(B, 3, 3)

    return rot


#------------------------Observation-----------------------------
def ee_position(
    env: ManagerBasedRLEnv,
    asset_cfg: SceneEntityCfg,
    link_name: str
) -> torch.Tensor:
    art = env.scene[asset_cfg.name]
    link_index = art.body_names.index(link_name)
    all_body_positions = art.data.body_state_w
    all_positions = all_body_positions[..., :3]
    origins = env.scene.env_origins.unsqueeze(1)
    all_positions = all_positions - origins
    ee_pos = all_positions[:, link_index, :]
    return ee_pos

def ee_velocity(env, asset_cfg: SceneEntityCfg, link_name: str):
    # Get the robot articulation and the specified link
    art = env.scene[asset_cfg.name]
    link_index = art.body_names.index(link_name)

    # Get linear velocity in world frame (shape: [N, 3])
    lin_vel = art.data.body_link_lin_vel_w[:, link_index, :]  # velocity in m/s

    return lin_vel

def ee_quater(
    env: ManagerBasedRLEnv,
    asset_cfg: SceneEntityCfg,
    link_name:str
) -> torch.Tensor:
    art = env.scene[asset_cfg.name]
    # link_pose = asset.data.link_state[:, asset.link_index(link_name), :7]
    link_idx = art.body_names.index(link_name)
    pos = art.data.body_state_w[:, link_idx, 0:3]
    # Orientation in [x, y, z, w] (Isaac Lab default)
    ee_quat = art.data.body_state_w[:, link_idx, 3:7]
    # ee_quat = asset.data.link_quat_w  #  pose = [x, y, z, qw, qx, qy, qz]
    return ee_quat

def goal_position(
    env: ManagerBasedRLEnv
) -> torch.Tensor: 
    object_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins
    return object_pos

def object_obs(
    env: ManagerBasedRLEnv,
) -> torch.Tensor:
    """
    Object observations (in world frame):
        object pos,
        object quat,
        left_eef to object,
        right_eef_to object,
    """

    body_pos_w = env.scene["ur5"].data.body_pos_w
    eef_idx = env.scene["ur5"].data.body_names.index("wrist_3_link")
    eef_pos = body_pos_w[:, eef_idx] - env.scene.env_origins

    object_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins
    object_quat = env.scene["object"].data.root_quat_w

    eef_to_object = object_pos - eef_pos

    return torch.cat(
        (
            object_pos,
            object_quat,
            eef_to_object,
        ),
        dim=1,
    )

def compute_cart_error(env, asset_cfg: SceneEntityCfg,link_name: str):
    # EE position and orientation
    ee_pos = ee_position(env, asset_cfg, link_name)          
    ee_rot = ee_quater(env, asset_cfg, link_name)            

    # Offset 0.1m along local X axis, transformed to world frame
    local_offset = torch.tensor([0.06, 0.0, 0.0], device=ee_pos.device).repeat(ee_pos.shape[0], 1)
    offset_world = quat_apply(ee_rot, local_offset)          

    # New reference point in world frame
    tip_pos = ee_pos + offset_world
    obj_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins 
    z_bias = torch.tensor([0.07, 0.0, -0.1], device=obj_pos.device).repeat(obj_pos.shape[0], 1)
    biased_target = obj_pos + z_bias  
    return tip_pos - obj_pos
    # return ee_position(env, asset_cfg,link_name) - (env.scene["object"].data.root_pos_w - env.scene.env_origins)
#---------------------------Reward-----------------------------
def reward_cartesian_distance(env, asset_cfg: SceneEntityCfg,link_name: str):
    """Reward based on a point 0.1m in the local X axis of EE approaching the object."""
    # EE position and orientation
    ee_pos = ee_position(env, asset_cfg, link_name)          
    ee_rot = ee_quater(env, asset_cfg, link_name)            

    # Offset 0.1m along local X axis, transformed to world frame
    local_offset = torch.tensor([0.06, 0.0, 0.0], device=ee_pos.device).repeat(ee_pos.shape[0], 1)
    offset_world = quat_apply(ee_rot, local_offset)          

    # New reference point in world frame
    tip_pos = ee_pos + offset_world                          

    # Object position in world frame (accounting for scene origins)
    obj_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins 
    z_bias = torch.tensor([0.01, 0.0, -0.2], device=obj_pos.device).repeat(obj_pos.shape[0], 1)
    biased_target = obj_pos + z_bias


    # Compute L2 distance from the tip to the object
    delta = tip_pos - biased_target
    weights = torch.tensor([1.0, 1.0, 2.5], device=delta.device)
    weighted_dist = torch.sqrt(torch.sum((delta * weights) ** 2, dim=-1))
    dist = torch.norm(tip_pos - biased_target, dim=-1)           

    # Smooth shaping + binary bonus for being very close
    shaped = 1.0 / (1.0 + weighted_dist) 
    close_bonus = (dist < 0.1).float()

    # Penalize high end-effector velocity
    ee_vel = ee_velocity(env, asset_cfg, link_name)
    vel_penalty = torch.norm(ee_vel, dim=-1)

    z_delta = biased_target[:, 2] - tip_pos[:, 2]
    z_reward = torch.clamp(0.05 - torch.abs(z_delta), min=0.0) * 2.0

    # Final reward
    reward = shaped + 1.0 * close_bonus - 0.1 * vel_penalty +z_reward#+no_contact_bonus
    return reward

def reward_ee_directed_toward_object(env, asset_cfg: SceneEntityCfg, link_name: str):
    """
    Reward for the end-effector's +X axis pointing toward the object.
    X-axis is assumed to be the forward/approach direction (e.g., gripper facing down).
    """
    ee_pos = ee_position(env, asset_cfg, link_name)          
    ee_rot = ee_quater(env, asset_cfg, link_name)            

    # Offset 0.1m along local X axis, transformed to world frame
    local_offset = torch.tensor([0.05, 0.0, 0.0], device=ee_pos.device).repeat(ee_pos.shape[0], 1)
    offset_world = quat_apply(ee_rot, local_offset)          

    # New reference point in world frame
    tip_pos = ee_pos + offset_world
    
    # Object position
    obj_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins  # (N, 3)
    object_quat = env.scene["object"].data.root_quat_w
    local_offset = torch.tensor([0.0, 0.0, -0.1], device=ee_pos.device).repeat(ee_pos.shape[0], 1)
    offset_world_obj = quat_apply(object_quat, local_offset)          

    # New reference point in world frame
    obj_pos = obj_pos + offset_world_obj 

    # Local +X axis in world frame
    ee_x_local = torch.tensor([1.0, 0.0, 0.0], device=ee_rot.device).repeat(ee_rot.shape[0], 1)
    ee_forward_world = quat_apply(ee_rot, ee_x_local)  # (N, 3)

    # Vector from EE to object
    to_obj_vec = obj_pos - tip_pos
    to_obj_vec = torch.nn.functional.normalize(to_obj_vec, dim=-1)
    ee_forward_world = torch.nn.functional.normalize(ee_forward_world, dim=-1)

    # Compute alignment: 1.0 means fully pointing at object
    alignment = torch.sum(to_obj_vec * ee_forward_world, dim=-1)  # (N,)

    # Optional: reward shaped by distance
    dist = torch.norm(obj_pos - tip_pos, dim=-1)
    shaped_dist = torch.exp(-dist)

    reward = alignment * shaped_dist  # encourages pointing as it gets closer

    return reward

def reward_ee_fully_aligned_to_object(env, asset_cfg: SceneEntityCfg, link_name: str):
    """Reward EE for being oriented such that it both points toward the object (+X)
    and aligns other axes (+Y and +Z) with the world/object frame."""

    # EE position and orientation
    ee_pos = ee_position(env, asset_cfg, link_name)          
    ee_rot = ee_quater(env, asset_cfg, link_name)            

    # Offset 0.1m along local X axis, transformed to world frame
    local_offset = torch.tensor([0.06, 0.0, 0.0], device=ee_pos.device).repeat(ee_pos.shape[0], 1)
    offset_world = quat_apply(ee_rot, local_offset)          

    # New reference point in world frame
    tip_pos = ee_pos + offset_world

    # Object position (centered w.r.t. env)
    obj_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins 

    z_bias = torch.tensor([0.0, 0.0, -0.2], device=obj_pos.device).repeat(obj_pos.shape[0], 1)
    biased_target = obj_pos + z_bias
    to_obj_vec = torch.nn.functional.normalize(biased_target - tip_pos, dim=-1)
    #to_obj_vec = torch.nn.functional.normalize(obj_pos - tip_pos, dim=-1)

    # EE local axes in world frame
    x_local = torch.tensor([1.0, 0.0, 0.0], device=ee_rot.device).repeat(ee_rot.shape[0], 1)
    y_local = torch.tensor([0.0, 1.0, 0.0], device=ee_rot.device).repeat(ee_rot.shape[0], 1)
    z_local = torch.tensor([0.0, 0.0, 1.0], device=ee_rot.device).repeat(ee_rot.shape[0], 1)

    ee_x_world = torch.nn.functional.normalize(quat_apply(ee_rot, x_local), dim=-1)
    ee_y_world = torch.nn.functional.normalize(quat_apply(ee_rot, y_local), dim=-1)
    ee_z_world = torch.nn.functional.normalize(quat_apply(ee_rot, z_local), dim=-1)

    align_x = torch.sum(to_obj_vec * ee_x_world, dim=-1)

    # Alignment of EE Z with world up [0, 0, 1]
    world_up = torch.tensor([0.0, 0.0, 1.0], device=ee_rot.device)
    align_z = torch.sum(ee_z_world * world_up, dim=-1).abs()


    world_y = torch.tensor([0.0, 1.0, 0.0], device=ee_rot.device)
    align_y = torch.sum(ee_y_world * world_y, dim=-1).abs()

    # Distance shaping
    dist = torch.norm(obj_pos - tip_pos, dim=-1)
    shaped_dist = torch.exp(-dist)

    # Final reward: weight alignments as needed
    reward = (
        3.0 * align_x +      # approaching object
        1.0 * align_y +      # gripper orientation aligned sideways
        1.0 * align_z        # gripper stays horizontal
    ) * shaped_dist

    return reward


def reward_z_axis_opposite(env, asset_cfg: SceneEntityCfg, link_name: str):
    ee_quat = ee_quater(env, asset_cfg, link_name)
    obj_quat = env.scene["object"].data.root_quat_w

    ee_rot = quat_to_matrix(ee_quat) 
    obj_rot = quat_to_matrix(obj_quat)


    ee_z = ee_rot[..., :, 1]
    obj_z = obj_rot[..., :, 2]

    dot = torch.sum(ee_z * (-obj_z), dim=-1)
    reward = torch.exp(dot)  # closer to -1 → higher reward

    return reward

def reward_z_axis_down(env, asset_cfg: SceneEntityCfg, link_name: str):
    """Reward when the EE Z-axis points down (aligned with world Z-)."""
    ee_quat = ee_quater(env, asset_cfg, link_name)  
    ee_rot = quat_to_matrix(ee_quat)                

 
    ee_z_axis = ee_rot[..., :, 2]  # (N, 3)

    # World downward Z-axis
    target_z_axis = torch.tensor([0.0, 0.0, -1.0], device=ee_z_axis.device)  


    dot = torch.sum(ee_z_axis * target_z_axis, dim=-1)  # (N,)

 
    reward = (dot + 1) / 2  # normalize to [0, 1]

    return reward

def reward_success_bonus(env, asset_cfg: SceneEntityCfg, link_name: str):
    """+10 when within 5 cm of goal, else 0."""
    ee_pos = ee_position(env, asset_cfg, link_name)          
    ee_rot = ee_quater(env, asset_cfg, link_name)            

    # Offset 0.1m along local X axis, transformed to world frame
    local_offset = torch.tensor([0.06, 0.0, 0.0], device=ee_pos.device).repeat(ee_pos.shape[0], 1)
    offset_world = quat_apply(ee_rot, local_offset)          

    # New reference point in world frame
    tip_pos = ee_pos + offset_world
    goal = env.scene["object"].data.root_pos_w - env.scene.env_origins
    inside = (torch.norm(tip_pos - goal, dim=-1) < 0.1).float()
    return inside #* (5.0 * (1 - env.episode_length_buf / env.max_episode_length))

def reward_effort_penalty(env):
    """Small negative penalty proportional to joint efforts."""
    efforts = env.action_manager.action#env.actions.joint_effort           
    return -torch.sum(torch.abs(efforts), dim=-1)

def penalize_joint_velocity(env):
    '''negative penalty proportional to jittery joint velocity'''
    robot = env.scene["ur5"]
    joint_vel = robot.data.joint_vel  # shape: (num_envs, num_joints)
    penalty = -torch.norm(joint_vel, dim=-1)  # L2 norm per env
    return penalty

def reward_action_l2(env):
    """Penalty on large actions (L2 norm)."""
    # Shape: (num_envs, action_dim)
    actions = env.action_manager.action  # this should hold the most recent action
    penalty = -torch.norm(actions, dim=-1)  # L2 norm across joints
    return penalty
#--------------------------Termination--------------------------
def termination_success(env, asset_cfg: SceneEntityCfg,link_name: str):
    """
    Returns True (per-env mask) when the end-effector is within 5cm of goal.
    """
    ee = ee_position(env, asset_cfg,link_name)       # your FK helper
    goal = env.scene["object"].data.root_pos_w - env.scene.env_origins                    # (num_envs, 3)
    close = torch.norm(ee - goal, dim=-1) < 0.1
    return close

def fall_off(env):
    obj_pos = env.scene["object"].data.root_pos_w  # (N, 3)
    table_height = 0.83  # Adjust to your table's Z value
    threshold = table_height - 0.05  # e.g., 5cm below table
    threshold1 = table_height + 0.2

    # Return a mask (True where object has fallen)
    return (obj_pos[:, 2] < threshold) | (obj_pos[:, 2] > threshold1)

def knocked_off(env):
    obj_ang = env.scene["object"].data.root_quat_w  # (N, 3)
    object_euler = quat_to_euler(obj_ang)           # (N, 3)

    # Get roll (x) and pitch (y)
    roll = object_euler[..., 0]
    pitch = object_euler[..., 1]
    yaw = object_euler[..., 2]

    # Knockover if abs(x or y) > 30 degrees (0.52 rad)
    is_knocked = (yaw.abs() > 3.14) | (roll > -2.45) | (roll < -3.24)#(roll.abs() > 1.52) | (pitch.abs() > 1.52) 
    return is_knocked
#-----------------------------------------Events----------------------------------------------------------------------
def close_gripper(env, asset_cfg, link_name, threshold=0.09):
    ee_pos = ee_position(env, asset_cfg, link_name)          
    ee_rot = ee_quater(env, asset_cfg, link_name)            

    # Offset 0.1m along local X axis, transformed to world frame
    local_offset = torch.tensor([0.12, 0.0, 0.0], device=ee_pos.device).repeat(ee_pos.shape[0], 1)
    offset_world = quat_apply(ee_rot, local_offset)          

    # New reference point in world frame
    tip_pos = ee_pos + offset_world
    obj_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins
    dist = torch.norm(tip_pos - obj_pos, dim=-1)
    return (dist < threshold)