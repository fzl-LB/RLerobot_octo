# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import math

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg,RigidObjectCfg
from isaaclab.assets import ArticulationCfg, AssetBaseCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass

from . import mdp

##
# Pre-defined configs
##

import sys
import os
sys.path.append(os.path.abspath("C:/Users/Administrator/Desktop/RLerobot_octo/RLerobot_octo/source/Assets"))
from robot.SO import SO_CFG 


##
# Scene definition
##


@configclass
class RlerobotOctoSceneCfg(InteractiveSceneCfg):
    """Designs the scene."""

    # Ground-plane
    ground = AssetBaseCfg(prim_path="/World/defaultGroundPlane", spawn=sim_utils.GroundPlaneCfg())

    # lights
    dome_light = AssetBaseCfg(
        prim_path="/World/Light", spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75))
    )

    # a modifier
    # Goal visualization marker
    # object = RigidObjectCfg(
    #     prim_path="{ENV_REGEX_NS}/Object",
    #     init_state=RigidObjectCfg.InitialStateCfg(pos=[0.0, 0.0, 0.88866], rot=[ 0.707,  0.707, 0, 0]),
    #     spawn=sim_utils.UsdFileCfg(
    #         usd_path=f"C:/Users/Administrator/Desktop/CGC_PARIS/objects/LaboratoryBottle01.usd", 
    #         scale=[0.001, 0.0011, 0.002],
    #         rigid_props=sim_utils.RigidBodyPropertiesCfg(
    #             disable_gravity=False,
    #             max_depenetration_velocity=5.0,
    #         ),
    #     ),
    # )

    # robot
    robot : ArticulationCfg = SO_CFG.replace(prim_path="{ENV_REGEX_NS}/robot")


##
# MDP settings
##


@configclass
class ActionsCfg:
    """Action specifications for the MDP."""

    joint_effort = mdp.JointEffortActionCfg(asset_name="robot", joint_names=["Rotation","Pitch","Elbow","Wrist_Pitch","Wrist_Roll","Jaw"], scale=100.0)


@configclass
class ObservationsCfg:
    """Observation specifications for the MDP."""

    @configclass
    class PolicyCfg(ObsGroup):
        """Observations for policy group."""

        # observation terms (order preserved)
        joint_pos_rel = ObsTerm(func=mdp.joint_pos_rel)
        joint_vel_rel = ObsTerm(func=mdp.joint_vel_rel)

        def __post_init__(self) -> None:
            self.enable_corruption = False
            self.concatenate_terms = True

    # observation groups
    policy: PolicyCfg = PolicyCfg()


@configclass
class EventCfg:
    """Configuration for events."""

    # reset
    reset_position = EventTerm(
        func=mdp.reset_joints_by_offset,
        mode="reset",
        params={
            "asset_cfg": SceneEntityCfg("robot", joint_names=["Rotation","Pitch","Elbow","Wrist_Pitch","Wrist_Roll","Jaw"]),
            "position_range": (-0.0, 0.0),
            "velocity_range": (-0.0, 0.0),
        },
    )
    ##`a modifier`
    # reset_object = EventTerm(
    #     func=mdp.reset_root_state_uniform,
    #     mode="reset",
    #     params={
    #         "pose_range": {
    #             "x": [0.35, 0.35],
    #             "y": [-0.0, 0.0],
    #             # "x": [0.25, 0.6],
    #             # "y": [-0.25, 0.25],
    #         },
    #         "velocity_range": {},
    #         "asset_cfg": SceneEntityCfg("object"),
    #     },
    # )

#####for Inspo#####
# @configclass
# class ObservationsCfg:
#     """Observation specifications for the MDP."""
#     @configclass
#     class PolicyCfg(ObsGroup):
#         """Observations for policy group."""
#         goal = ObsTerm(func=mdp.object_obs)
#         end_effector = ObsTerm(func=mdp.ee_position,
#                                params={"asset_cfg": SceneEntityCfg("robot"), "link_name": "base_link_01"})
#         EE_rot = ObsTerm(func=mdp.ee_quater,
#                                params={"asset_cfg": SceneEntityCfg("robot"), "link_name": "base_link_01"})
#         #observing cartesian error between end effector and object
#         cart_error = ObsTerm(
#             func=mdp.compute_cart_error,
#             params={"asset_cfg": SceneEntityCfg("robot"), "link_name": "base_link_01"}
#         )
#         #observing joint states of the robot
#         joint_pos = ObsTerm(func=mdp.joint_pos, params={"asset_cfg": SceneEntityCfg("robot")})
#         joint_vel = ObsTerm(func=mdp.joint_vel, params={"asset_cfg": SceneEntityCfg("robot")})

#         def __post_init__(self) -> None:
#             self.enable_corruption = False
#             self.concatenate_terms = True

#     # observation groups
#     policy: PolicyCfg = PolicyCfg()

@configclass
class RewardsCfg:
    """Reward terms for the MDP."""
    # (1) Constant running reward
    alive = RewTerm(func=mdp.is_alive, weight=1.0)
    # (2) Failure penalty
    terminating = RewTerm(func=mdp.is_terminated, weight=-2.0)
    #####for Inspo#####
    # # (3) cartesian distance 
    # cart_dist = RewTerm(
    #     func=mdp.reward_cartesian_distance,
    #     weight=3.0,  # + weight bcoz function is already -
    #     params={"asset_cfg": SceneEntityCfg("robot"), "link_name": "base_link_01"}
    # )
    # axis_align = RewTerm(
    #     func=mdp.reward_ee_fully_aligned_to_object,
    #     weight=3.0,  # + weight bcoz function is already -
    #     params={"asset_cfg": SceneEntityCfg("robot"), "link_name": "base_link_01"}
    # )
    # success = RewTerm(
    #     func=mdp.reward_success_bonus,
    #     weight=3.0,
    #     params={"asset_cfg": SceneEntityCfg("robot"), "link_name": "base_link_01"}
    # )
    # #Velocity penalties : Helps avoid jittery movements
    # joint_vel_penalty = RewTerm(
    #     func=mdp.penalize_joint_velocity,
    #     weight=0.1
    # )

@configclass
class TerminationsCfg:
    """Termination terms for the MDP."""
    
    # (1) Time out
    time_out = DoneTerm(func=mdp.time_out, time_out=True)
     # (2) Joint out of bounds for each joint
    out_of_bounds_joint_1 = DoneTerm(
        func=mdp.joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot", joint_names=["Rotation"]),
            "bounds": (-3.0, 3.0),
        },)
    out_of_bounds_joint_5 = DoneTerm(
        func=mdp.joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot", joint_names=["Pitch"]),
            "bounds": (-3.0, 3.0),
        },)
    out_of_bounds_joint_6 = DoneTerm(
        func=mdp.joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot", joint_names=["Elbow"]),
            "bounds": (-3.0, 3.0),
        },)
    out_of_bounds_joint_7 = DoneTerm(
        func=mdp.joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot", joint_names=["Wrist_Pitch"]),
            "bounds": (-3.0, 3.0),
        },)
    out_of_bounds_joint_8 = DoneTerm(
        func=mdp.joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot", joint_names=["Wrist_Roll"]),
            "bounds": (-3.0, 3.0),
        },)
    out_of_bounds_joint_8 = DoneTerm(
        func=mdp.joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot", joint_names=["Jaw"]),
            "bounds": (-3.0, 3.0),
        },)

##
# Environment configuration
##


@configclass
class RlerobotOctoEnvCfg(ManagerBasedRLEnvCfg):
    # Scene settings
    scene: RlerobotOctoSceneCfg = RlerobotOctoSceneCfg(num_envs=4096, env_spacing=4.0)
    # Basic settings
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    events: EventCfg = EventCfg()
    # MDP settings
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()

    # Post initialization
    def __post_init__(self) -> None:
        """Post initialization."""
        # general settings
        self.decimation = 2
        self.episode_length_s = 5
        # viewer settings
        self.viewer.eye = (8.0, 0.0, 5.0)
        # simulation settings
        self.sim.dt = 1 / 120
        self.sim.render_interval = self.decimation